package testNew;


public class WebOrder {
	
public static void main(String[] args) {
	

StartingPoint.run("chrome");

}

}
